import requests.exceptions
from flask import Flask, request
import json
from requests import get
app = Flask (__name__)
app.config['SECRET_KEY'] = 'skillfactory_secret_key'
@app.route('/')
@app.route('/scan', methods = ["GET"])
def do_GET():
    data = json.loads(request.get_data().decode('utf-8'))
    network_ip = (data['target'][:data['target'].rfind('.')]) + '.'
    response ={}  #словарь с просканированными ip-шниками
    for ip in range (1 , int (data['count']) + 1):
        current_ip = network_ip + str(ip)
        try:
            response[current_ip] = get('https://' + current_ip,timeout= 0.5).status_code
        except requests.exceptions.ConnectTimeout:
            response[current_ip] = 404
    return response
@app.route('/sendhttp', methods = ["POST"])
def do_POST():
    data = json.loads(request.get_data().decode('utf-8'))
    try :
        response = requests.request(method = data['Method'], headers = {data['Header']:data['Header-value']}, url = 'https://' + data["Target"])
    except KeyError as err:
        return {'status_code': 400, 'content': err}
    return response.content
if __name__ == '__main__':
    app.run (port = 8081, host = '0.0.0.0')
